import React from "react";
import { Routes, Route, Link } from "react-router-dom";
import ProductList from "./ProductList";
import ProductForm from "./ProductForm";
import ProductView from "./ProductView";
import "./App.css";

function App() {
  return (
    <div>
      <h1>Product Management</h1>
      <nav>
        <Link to="/">Product List</Link> | <Link to="/add">Add Product</Link>
      </nav>

      <Routes>
        <Route path="/" element={<ProductList />} />
        <Route path="/add" element={<ProductForm />} />
        <Route path="/edit/:id" element={<ProductForm />} />
        <Route path="/view/:id" element={<ProductView />} />
      </Routes>
    </div>
  );
}

export default App;
