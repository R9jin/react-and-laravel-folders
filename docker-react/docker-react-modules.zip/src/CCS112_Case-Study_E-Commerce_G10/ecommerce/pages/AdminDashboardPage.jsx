import React, { useState, useEffect, useContext } from "react";
import { useDropzone } from "react-dropzone";
import { ProductsContext } from "../context/ProductsContext";
import styles from "../styles/AdminDashboard.module.css";

/**
 * AdminDashboardPage Component
 *
 * Provides an interface for admin users to manage products.
 */
function AdminDashboardPage() {
  const { products, updateProducts } = useContext(ProductsContext);
  const [image, setImage] = useState(null);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: { "image/*": [] },
    onDrop: (acceptedFiles) => {
      const file = acceptedFiles[0];
      if (file) {
        const reader = new FileReader();
        reader.onloadend = () => setImage(reader.result);
        reader.readAsDataURL(file);
      }
    },
  });

  const [form, setForm] = useState({
    id: "",
    name: "",
    category: "",
    price: "",
    description: "",
    stock: "",
    rating: "",
  });

  const [isEditing, setIsEditing] = useState(false);

  const categoryPrefixes = { Appetizer: "AP", Main: "MA", Dessert: "DE", Drinks: "DR" };
  const [categoryCounters, setCategoryCounters] = useState({ AP: 0, MA: 0, DE: 0, DR: 0 });

  useEffect(() => {
    const newCounters = { AP: 0, MA: 0, DE: 0, DR: 0 };
    products.forEach((p) => {
      const prefix = p.id.slice(0, 2);
      const num = parseInt(p.id.slice(2));
      if (!isNaN(num) && num > (newCounters[prefix] || 0)) {
        newCounters[prefix] = num;
      }
    });
    setCategoryCounters(newCounters);
  }, [products]);

  const generateNextId = (category) => {
    const prefix = categoryPrefixes[category];
    if (!prefix) return `P${Math.floor(Math.random() * 1000)}`;

    const nextNum = (categoryCounters[prefix] || 0) + 1;
    setCategoryCounters((prev) => ({ ...prev, [prefix]: nextNum }));
    return `${prefix}${nextNum.toString().padStart(3, "0")}`;
  };

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleAddProduct = (e) => {
    e.preventDefault();
    if (!form.name || !form.category || !form.price || !image) {
      alert("Please fill all required fields and upload an image.");
      return;
    }
    if (!window.confirm("Are you sure you want to add this product?")) return;

    const newProduct = {
      id: generateNextId(form.category),
      name: form.name,
      category: form.category,
      price: parseFloat(form.price),
      image,
      description: form.description,
      rating: parseFloat(form.rating) || 0,
      stock: parseInt(form.stock) || 0,
      sold: 0,
      wishlisted: false,
    };

    updateProducts([...products, newProduct]);
    resetForm();
    alert("Product added successfully!");
  };

  const handleDelete = (id) => {
    if (!window.confirm("Are you sure you want to delete this product?")) return;
    updateProducts(products.filter((p) => p.id !== id));
    alert("Product deleted successfully!");
  };

  const handleEdit = (product) => {
    setIsEditing(true);
    setForm(product);
    setImage(product.image);
  };

  const handleUpdate = (e) => {
    e.preventDefault();
    if (!form.name || !form.category || !form.price) {
      alert("Please fill all required fields.");
      return;
    }
    if (!window.confirm("Save changes to this product?")) return;

    updateProducts(products.map((p) => (p.id === form.id ? { ...form, image } : p)));
    resetForm();
  };

  const resetForm = () => {
    setForm({ id: "", name: "", category: "", price: "", description: "", stock: "", rating: "" });
    setImage(null);
    setIsEditing(false);
  };

  return (
    <div className={styles.adminDashboard}>
      <h1>Admin Dashboard</h1>

      <form className={styles.addForm} onSubmit={isEditing ? handleUpdate : handleAddProduct}>
        <div className={styles.dropzone} {...getRootProps()}>
          <input {...getInputProps()} />
          {isDragActive ? (
            <p>Drop the image here...</p>
          ) : image ? (
            <img src={image} alt="preview" className={styles.preview} />
          ) : (
            <p>Drag & drop image here, or click to upload</p>
          )}
        </div>

        <input name="name" placeholder="Food Name" value={form.name} onChange={handleChange} />
        <select name="category" value={form.category} onChange={handleChange} required>
          <option value="">Select Category</option>
          <option value="Appetizer">Appetizer</option>
          <option value="Main">Main</option>
          <option value="Dessert">Dessert</option>
          <option value="Drinks">Drinks</option>
        </select>
        <input name="price" placeholder="Price" type="number" value={form.price} onChange={handleChange} />
        <textarea name="description" placeholder="Description" value={form.description} onChange={handleChange} />
        <input name="stock" placeholder="Stock" type="number" value={form.stock} onChange={handleChange} />
        <input name="rating" placeholder="Rating (0–5)" type="number" step="0.1" value={form.rating} onChange={handleChange} />

        <button type="submit">{isEditing ? "Update Product" : "Add Product"}</button>
        {isEditing && (
          <button type="button" onClick={resetForm} className={styles.cancelBtn}>
            Cancel
          </button>
        )}
      </form>

      <h2>All Products</h2>
      {products.length === 0 ? (
        <p>No products available.</p>
      ) : (
        <table className={styles.productsTable}>
          <thead>
            <tr>
              <th>ID</th>
              <th>Image</th>
              <th>Name</th>
              <th>Category</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Rating</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id}>
                <td>{p.id}</td>
                <td>
                  <img src={p.image} alt={p.name} className={styles.thumb} />
                </td>
                <td>{p.name}</td>
                <td>{p.category}</td>
                <td>₱{p.price}</td>
                <td>{p.stock}</td>
                <td>{p.rating}</td>
                <td>
                  <button onClick={() => handleEdit(p)}>Edit</button>
                  <button onClick={() => handleDelete(p.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default AdminDashboardPage;
