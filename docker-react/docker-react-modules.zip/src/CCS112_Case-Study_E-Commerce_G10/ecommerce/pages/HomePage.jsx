import React, { useContext } from "react";
import { ProductsContext } from "../context/ProductsContext";
import CategoryCards from "../components/CategoryCard";
import ProductCard from "../components/ProductCard";
import styles from "../styles/HomePage.module.css"; // ✅ CSS Module

function HomePage() {
  const { products } = useContext(ProductsContext);

  const featured = [...products]
    .filter((p) => p.rating >= 4.0)
    .slice(0, 5);

  const bestSellers = [...products]
    .sort((a, b) => b.sold - a.sold)
    .slice(0, 5);

  return (
    <main className={styles.homepage}>
      {/* CATEGORY NAVIGATION SECTION */}
      <section>
        <CategoryCards />
      </section>
      
      {/* FEATURED PRODUCTS SECTION */}
      <section className={styles.categorySection}>
        <h2>FEATURED</h2>
        <div className={styles.productList}>
          {featured.map((item) => (
            <>
              <ProductCard key={item.id + "-1"} product={item} />
              <ProductCard key={item.id + "-2"} product={item} />
            </>
          ))}
        </div>
      </section>

      {/* BEST SELLERS SECTION */}
      <section className={styles.categorySection}>
        <h2>BEST SELLERS</h2>
        <div className={styles.productList}>
          {bestSellers.map((item) => (
            <>
              <ProductCard key={item.id + "-1"} product={item} />
              <ProductCard key={item.id + "-2"} product={item} />
            </>
          ))}
        </div>
      </section>
    </main>
  );
}

export default HomePage;
