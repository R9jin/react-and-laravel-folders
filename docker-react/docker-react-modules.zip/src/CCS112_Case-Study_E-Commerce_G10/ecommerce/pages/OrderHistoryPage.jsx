import React, { useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { OrderHistoryContext } from "../context/OrderHistoryContext";
import { CartContext } from "../context/CartContext";
import productsData from "../data/products.json";
import styles from "../styles/OrderHistory.module.css"; // ✅ CSS Module

export default function OrderHistoryPage() {
  const { transactions } = useContext(OrderHistoryContext);
  const { addToCart, clearCart } = useContext(CartContext);
  const navigate = useNavigate();
  const [statusesMap, setStatusesMap] = useState({});

  const statuses = ["Ordered", "Payment", "Confirmation", "Delivery"];

  useEffect(() => {
    const map = {};
    transactions.forEach((t) => {
      const saved = JSON.parse(localStorage.getItem(`track_${t.transactionId}`));
      map[t.transactionId] = saved?.statusIndex || 0;
    });
    setStatusesMap(map);
  }, [transactions]);

  const getProductImage = (id) => {
    const product = productsData.find((p) => p.id === id);
    return product?.image || "";
  };

  const handleBuyAgain = (items) => {
    clearCart();
    items.forEach((item) => {
      const product = productsData.find((p) => p.id === item.id);
      if (!product) return;

      addToCart({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        quantity: item.quantity,
      });
    });
    navigate("/checkout");
  };

  const getSafePrice = (item) =>
    item.price ?? productsData.find((p) => p.id === item.id)?.price ?? 0;

  return (
    <div className={styles.orderContainer}>
      <h2>Order History</h2>
      {transactions.length === 0 && <p>No orders found.</p>}

      {transactions.map((transaction) => {
        const statusIndex = statusesMap[transaction.transactionId] || 0;
        const isDelivered = statusIndex === statuses.length - 1;

        return (
          <div key={transaction.transactionId} className={styles.cartItem}>
            <div className={styles.cartInfo}>
              <div className={styles.transactionInfo}>
                <p><strong>Transaction ID:</strong> {transaction.transactionId}</p>
                <p><strong>Email:</strong> {transaction.user}</p>
                <p><strong>Date:</strong> {transaction.date}</p>
              </div>

              <table className={styles.orderTable}>
                <thead>
                  <tr>
                    <th>Image</th>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  {transaction.items.map((item) => {
                    const price = getSafePrice(item);
                    return (
                      <tr key={item.id}>
                        <td>
                          {getProductImage(item.id) && (
                            <img
                              src={getProductImage(item.id)}
                              alt={item.name}
                              className={styles.orderItemImg}
                            />
                          )}
                        </td>
                        <td>{item.name}</td>
                        <td>{item.quantity}</td>
                        <td>₱{price.toFixed(2)}</td>
                        <td>₱{(price * item.quantity).toFixed(2)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              <p className={styles.transactionTotal}>
                <strong>Total:</strong> ₱{(transaction.total ?? 0).toFixed(2)}
              </p>

              {isDelivered ? (
                <button
                  className={styles.buyAgainBtn}
                  onClick={() => handleBuyAgain(transaction.items)}
                >
                  Buy Again
                </button>
              ) : (
                <button
                  className={styles.trackOrderBtn}
                  onClick={() =>
                    navigate(`/track-order/${transaction.transactionId}`)
                  }
                >
                  Track Order
                </button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
