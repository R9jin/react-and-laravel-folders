import React, { useState, useContext } from "react";
import { ProductsContext } from "../context/ProductsContext";
import ProductCard from "../components/ProductCard";
import styles from "../styles/HomePage.module.css";

/**
 * CategoryPage Component
 *
 * Displays products grouped by category with filtering and sorting options.
 */
function CategoryPage() {
  const { products } = useContext(ProductsContext);

  const [sortOption, setSortOption] = useState("default");
  const [priceRange, setPriceRange] = useState("all");
  const [minRating, setMinRating] = useState("all");

  const filterAndSort = (list) => {
    let filtered = [...list];

    if (priceRange !== "all") {
      const [min, max] = priceRange.split("-").map(Number);
      filtered = filtered.filter((p) => p.price >= min && p.price <= max);
    }

    if (minRating !== "all") {
      filtered = filtered.filter((p) => p.rating >= Number(minRating));
    }

    if (sortOption === "price-asc") {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sortOption === "price-desc") {
      filtered.sort((a, b) => b.price - a.price);
    } else if (sortOption === "newest") {
      filtered.sort((a, b) => new Date(b.dateAdded) - new Date(a.dateAdded));
    }

    return filtered;
  };

  const appetizers = filterAndSort(products.filter((p) => p.category === "Appetizers"));
  const mains = filterAndSort(products.filter((p) => p.category === "Main Course"));
  const desserts = filterAndSort(products.filter((p) => p.category === "Desserts"));
  const drinks = filterAndSort(products.filter((p) => p.category === "Drinks"));
  const streetFoods = filterAndSort(products.filter((p) => p.category === "Street Foods"));

  return (
    <main className={styles.homepage}>
      {/* FILTER BAR */}
      <div className={styles.filterBar}>
        <div className={styles.filterItem}>
          <label>Sort By:</label>
          <select value={sortOption} onChange={(e) => setSortOption(e.target.value)}>
            <option value="default">Default</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="newest">Newest Arrivals</option>
          </select>
        </div>

        <div className={styles.filterItem}>
          <label>Price Range:</label>
          <select value={priceRange} onChange={(e) => setPriceRange(e.target.value)}>
            <option value="all">All</option>
            <option value="0-100">₱0 - ₱100</option>
            <option value="100-300">₱100 - ₱300</option>
            <option value="300-500">₱300 - ₱500</option>
            <option value="500-9999">₱500+</option>
          </select>
        </div>

        <div className={styles.filterItem}>
          <label>Rating:</label>
          <select value={minRating} onChange={(e) => setMinRating(e.target.value)}>
            <option value="all">All</option>
            <option value="3">3★ & up</option>
            <option value="4">4★ & up</option>
            <option value="5">5★ only</option>
          </select>
        </div>
      </div>

      {/* CATEGORY SECTIONS */}
      {[
        { id: "appetizers", title: "APPETIZERS", items: appetizers },
        { id: "main-course", title: "MAIN COURSE", items: mains },
        { id: "desserts", title: "DESSERTS", items: desserts },
        { id: "street-foods", title: "STREET FOODS", items: streetFoods },
        { id: "drinks", title: "DRINKS", items: drinks },
      ].map((cat) => (
        <section key={cat.id} id={cat.id} className={styles.categorySection}>
          <h2>{cat.title}</h2>
          <div className={styles.productList}>
            {cat.items.map((item) => (
              <ProductCard key={item.id} product={item} />
            ))}
          </div>
        </section>
      ))}
    </main>
  );
}

export default CategoryPage;
