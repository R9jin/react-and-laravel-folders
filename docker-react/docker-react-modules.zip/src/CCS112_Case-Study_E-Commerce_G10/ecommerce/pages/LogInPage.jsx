import React, { useState, useEffect } from "react";
import styles from "../styles/LogInPage.module.css"; // ✅ CSS Module
import signInBanner from "../assets/signInBanner.png";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import usersData from "../data/users.json";

const safeParse = (key) => {
  try {
    const value = localStorage.getItem(key);
    if (!value) return null;
    return JSON.parse(value);
  } catch {
    return null;
  }
};

function LogInPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [agree, setAgree] = useState(false);

  const navigate = useNavigate();
  const { login } = useAuth();

  useEffect(() => {
    const existingUsers = safeParse("users") || [];
    if (existingUsers.length === 0) {
      localStorage.setItem("users", JSON.stringify(usersData));
    }
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();

    const storedUsers = safeParse("users") || [];
    const user = storedUsers.find(
      (u) => u.email === email.trim() && u.password === password
    );

    if (!user) {
      alert("Invalid email or password. This account may have been deleted.");
      return;
    }

    if (!agree) {
      alert("You must agree to the terms & policy before logging in.");
      return;
    }

    localStorage.setItem("currentUser", JSON.stringify(user));
    localStorage.setItem("isLoggedIn", "true");
    login(user);
    navigate("/home", { replace: true });
    setTimeout(() => alert(`Welcome back, ${user.name}!`), 100);
  };

  return (
    <div className={styles.loginWrapper}>
      {/* LEFT SIDE: Login Form */}
      <div className={styles.loginFormContainer}>
        <h2>Welcome back!</h2>
        <p>Enter your credentials to access your account</p>

        <form onSubmit={handleSubmit} className={styles.loginForm}>
          <label>Email address</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            required
          />

          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter your password"
            required
          />

          <div className={styles.loginOptions}>
            <div>
              <input
                type="checkbox"
                id="agree"
                checked={agree}
                onChange={(e) => setAgree(e.target.checked)}
              />
              <label htmlFor="agree"> I agree to the terms & policy</label>
            </div>
            <button
              type="button"
              className={styles.forgot}
              onClick={() => alert("Password reset feature coming soon.")}
            >
              Forgot password?
            </button>
          </div>

          <button
            type="submit"
            className={styles.loginBtn}
            disabled={!email || !password}
          >
            Login
          </button>
        </form>

        <p className={styles.signupText}>
          Don’t have an account?{" "}
          <Link to="/signup" className={styles.signupLink}>
            Sign up
          </Link>
        </p>
      </div>

      {/* RIGHT SIDE: Banner Image */}
      <div className={styles.loginBanner}>
        <img src={signInBanner} alt="Sign in banner" />
      </div>
    </div>
  );
}

export default LogInPage;
