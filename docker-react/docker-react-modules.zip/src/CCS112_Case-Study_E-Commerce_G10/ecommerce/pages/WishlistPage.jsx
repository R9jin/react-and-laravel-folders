import { useContext, useEffect, useState } from "react";
import { CartContext } from "../context/CartContext"; // access cart actions
import { WishlistContext } from "../context/WishlistContext"; // access wishlist actions
import WishlistCard from "../components/WishlistCard"; // reusable card component for wishlist items
import styles from "../styles/WishlistPage.module.css"; // ✅ CSS Module
import productsData from "../data/products.json"; // static product data

export default function WishListPage() {
  const { addToCart } = useContext(CartContext);
  const { wishlistItems, removeFromWishlist } = useContext(WishlistContext);

  const [allProducts, setAllProducts] = useState([]);

  useEffect(() => {
    setAllProducts(productsData);
  }, []);

  const wishlistProducts = allProducts.filter((p) =>
    wishlistItems.includes(p.id)
  );

  const handleAddCart = (product) => {
    addToCart({ ...product, quantity: 1 });
    alert(`${product.name} added to cart!`);
  };

  return (
    <main className={styles.wishlistPage}>
      {wishlistProducts.length === 0 ? (
        <p className={styles.emptyMessage}>No wishlisted items yet.</p>
      ) : (
        wishlistProducts.map((product) => (
          <WishlistCard
            key={product.id}
            product={product}
            onRemove={() => removeFromWishlist(product.id)}
            onAddCart={() => handleAddCart(product)}
            onBuyNow={() => {
              handleAddCart(product);
              window.location.href = "/checkout";
            }}
          />
        ))
      )}
    </main>
  );
}
