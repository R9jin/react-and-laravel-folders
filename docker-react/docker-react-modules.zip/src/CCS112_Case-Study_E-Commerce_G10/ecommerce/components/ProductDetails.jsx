import { useState, useEffect, useContext } from "react";
import { useNavigate } from "react-router-dom";
import starIcon from "../assets/star.png";
import heartIcon from "../assets/heart.png";
import cartIcon from "../assets/cart.png";
import styles from "../styles/ProductDetails.module.css";
import { CartContext } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";

function ProductDetails({ product }) {
  const [quantity, setQuantity] = useState(1);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [showNotice, setShowNotice] = useState(false);

  const { addToCart } = useContext(CartContext);
  const navigate = useNavigate();
  const { isLoggedIn } = useAuth();
  const currentUser = localStorage.getItem("currentUser");
  const wishlistKey = `wishlist_${currentUser}`;

  useEffect(() => {
    if (isLoggedIn && currentUser) {
      const savedWishlist = JSON.parse(localStorage.getItem(wishlistKey)) || [];
      setIsWishlisted(savedWishlist.includes(product.id));
    } else {
      setIsWishlisted(false);
    }
  }, [product.id, currentUser, isLoggedIn, wishlistKey]);

  const toggleWishlist = () => {
    if (!isLoggedIn || !currentUser) return alert("Please log in first");
    const savedWishlist = JSON.parse(localStorage.getItem(wishlistKey)) || [];
    const updated = isWishlisted
      ? savedWishlist.filter((id) => id !== product.id)
      : [...savedWishlist, product.id];
    localStorage.setItem(wishlistKey, JSON.stringify(updated));
    setIsWishlisted(!isWishlisted);
  };

  const handleAddToCart = () => {
    addToCart({ ...product, quantity });
    setShowNotice(true);
    alert(`${quantity} of ${product.name} added to cart!`);
    setTimeout(() => setShowNotice(false), 1500);
  };

  const handleBuyNow = () => {
    addToCart({ ...product, quantity });
    navigate("/checkout");
  };

  const fullStars = Math.round(product.rating);

  if (!product) return <p>Loading product details...</p>;

  return (
    <div className={styles.productDetailsPage}>
      {/* Image gallery */}
      <div className={styles.imageGallery}>
        <div className={styles.thumbnails}>
          {[product.image, product.image, product.image].map((img, i) => (
            <img key={i} src={img} alt="thumb" className={styles.thumb} />
          ))}
        </div>
        <div className={styles.mainImage}>
          <img src={product.image} alt={product.name} />
        </div>
      </div>

      {/* Details section */}
      <div className={styles.detailsSection}>
        <h2>{product.name}</h2>
        <p className={styles.price}>₱{product.price.toFixed(2)}</p>

        <div className={styles.rating}>
          {[...Array(5)].map((_, i) => (
            <img
              key={i}
              src={starIcon}
              alt="star"
              className={`${styles.star} ${i < fullStars ? styles.filled : ""}`}
            />
          ))}
          <span className={styles.reviewCount}>(32 reviews)</span>
        </div>

        <p className={styles.description}>{product.description}</p>

        <ul className={styles.features}>
          <li>Lorem ipsum dolor sit amet</li>
          <li>Consectetur adipiscing elit</li>
          <li>Sed do eiusmod tempor incididunt</li>
        </ul>

        <div className={styles.actions}>
          <div className={styles.productDetailQuantity}>
            <button onClick={() => setQuantity((q) => Math.max(1, q - 1))}>−</button>
            <span>{quantity}</span>
            <button onClick={() => setQuantity((q) => q + 1)}>+</button>
          </div>

          <button
            className={styles.productDetailAddCart}
            onClick={handleAddToCart}
          >
            <img src={cartIcon} alt="cart" /> Add to Cart
          </button>
        </div>

        {showNotice && <div className={styles.cartNotice}>Added to cart!</div>}

        <button
          className={styles.productDetailBuyNow}
          onClick={handleBuyNow}
        >
          Buy Now
        </button>

        <div className={styles.extraInfo}>
          <p>Free shipping on orders over ₱100</p>
          <p>Delivery in 3–7 working days</p>
        </div>

        <img
          src={heartIcon}
          alt="wishlist"
          className={`${styles.wishlistIcon} ${isWishlisted ? styles.active : ""}`}
          onClick={toggleWishlist}
        />
      </div>
    </div>
  );
}

export default ProductDetails;
