import { createContext, useState, useEffect } from "react";
import { useAuth } from "./AuthContext";

// Create a context to share order history data across components
export const OrderHistoryContext = createContext();

/**
 * OrderHistoryProvider Component
 *
 * Provides order history data and functions to manage it for the current user.
 * Features:
 * - Loads saved transactions from localStorage when a user logs in
 * - Saves transactions automatically when they change
 * - Allows adding new transactions
 * - Allows clearing all transactions
 */
export const OrderHistoryProvider = ({ children }) => {
  // Get the currently logged-in user from AuthContext
  const { currentUser } = useAuth();

  // State to store the user's transactions
  const [transactions, setTransactions] = useState([]);

  /**
   * Load transactions from localStorage when currentUser changes
   *
   * - If no user is logged in, reset transactions to an empty array
   * - Each user's transactions are saved under a unique key based on their email
   * - If transactions exist in localStorage, parse and load them into state
   */
  useEffect(() => {
    if (!currentUser) {
      setTransactions([]);
      return;
    }

    const key = `transactions_${currentUser.email}`;
    const saved = JSON.parse(localStorage.getItem(key)) || [];
    setTransactions(saved);
  }, [currentUser]);

  /**
   * Save transactions to localStorage whenever they change
   *
   * - Skips saving if no user is logged in
   * - Ensures each user has their own transaction history saved separately
   */
  useEffect(() => {
    if (!currentUser) return;
    const key = `transactions_${currentUser.email}`;
    localStorage.setItem(key, JSON.stringify(transactions));
  }, [transactions, currentUser]);

  /**
   * Add a new transaction to the user's history
   *
   * - Appends the new transaction to the existing list in state
   * - Triggers saving to localStorage automatically via the above useEffect
   */
  const addTransaction = (newTransaction) => {
    setTransactions((prev) => [...prev, newTransaction]);
  };

  /**
   * Clear all transactions for the current user
   *
   * - Resets the transactions state to an empty array
   * - Removes the saved transaction data from localStorage
   */
  const clearTransactions = () => {
    setTransactions([]);
    if (currentUser) {
      localStorage.removeItem(`transactions_${currentUser.email}`);
    }
  };

  // Provide transactions and management functions to the rest of the app
  return (
    <OrderHistoryContext.Provider
      value={{ transactions, addTransaction, clearTransactions }}
    >
      {children}
    </OrderHistoryContext.Provider>
  );
};
