import React, { createContext, useContext, useState, useEffect } from "react";

// Create a new context for authentication
const AuthContext = createContext();

export function AuthProvider({ children }) {
  // Tracks whether a user is logged in
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  // Stores the currently logged-in user’s information
  const [currentUser, setCurrentUser] = useState(null);

  // Runs once when the component mounts to restore login session if it exists
  useEffect(() => {
    // Check if "isLoggedIn" exists in localStorage and convert it to a boolean
    const storedLogin = localStorage.getItem("isLoggedIn") === "true";

    // Try to parse stored user data safely in case it's corrupted or missing
    let storedUser = null;
    try {
      storedUser = JSON.parse(localStorage.getItem("currentUser"));
    } catch {
      storedUser = null;
    }

    // Get all registered users from localStorage (used to verify session validity)
    const users = JSON.parse(localStorage.getItem("users")) || [];

    // If a login session exists and the user is still registered, restore session
    if (storedLogin && storedUser && users.some(u => u.email === storedUser.email)) {
      setIsLoggedIn(true);
      setCurrentUser(storedUser);
    } else {
      // If the saved session is invalid or user was deleted, clear it completely
      setIsLoggedIn(false);
      setCurrentUser(null);
      localStorage.removeItem("isLoggedIn");
      localStorage.removeItem("currentUser");
    }
  }, []);

  // Handles logging in a user by saving their info and session state
  const login = (user) => {
    setIsLoggedIn(true);
    setCurrentUser(user);
    localStorage.setItem("isLoggedIn", "true");
    localStorage.setItem("currentUser", JSON.stringify(user));
  };

  // Handles logging out by clearing session data and resetting state
  const logout = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("currentUser");
  };

  // Provide the authentication data and actions to the rest of the app
  return (
    <AuthContext.Provider value={{ isLoggedIn, currentUser, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

// Custom hook to easily access authentication context in other components
export const useAuth = () => useContext(AuthContext);
