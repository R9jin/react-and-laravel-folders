import { createContext, useState, useEffect } from "react";
import { useAuth } from "./AuthContext";

// Create a context to share wishlist data across components
export const WishlistContext = createContext();

/**
 * WishlistProvider Component
 *
 * Provides wishlist data and functions to manage it for the current user.
 * Features:
 * - Loads wishlist items from localStorage when a user logs in
 * - Saves wishlist automatically whenever it changes
 * - Allows adding, removing, and toggling items in the wishlist
 */
export const WishlistProvider = ({ children }) => {
  // Get the currently logged-in user from AuthContext
  const { currentUser } = useAuth();

  // State to store the list of wishlist item IDs
  const [wishlistItems, setWishlistItems] = useState([]);

  /**
   * Load the user's wishlist from localStorage when currentUser changes
   *
   * - If no user is logged in, resets the wishlist to an empty array
   * - Each user's wishlist is saved under a unique key based on their email
   * - If saved data exists, parse and load it into state
   */
  useEffect(() => {
    if (!currentUser) {
      setWishlistItems([]);
      return;
    }
    const key = `wishlist_${currentUser.email}`;
    const saved = JSON.parse(localStorage.getItem(key)) || [];
    setWishlistItems(saved);
  }, [currentUser]);

  /**
   * Save the user's wishlist to localStorage whenever it changes
   *
   * - Skips saving if no user is logged in
   * - Ensures each user has their own wishlist saved separately
   */
  useEffect(() => {
    if (!currentUser) return;
    const key = `wishlist_${currentUser.email}`;
    localStorage.setItem(key, JSON.stringify(wishlistItems));
  }, [wishlistItems, currentUser]);

  /**
   * Add a product to the wishlist
   *
   * - Checks if the product is already in the wishlist
   * - Adds the product ID only if it doesn't already exist
   */
  const addToWishlist = (productId) => {
    setWishlistItems((prev) => (prev.includes(productId) ? prev : [...prev, productId]));
  };

  /**
   * Remove a product from the wishlist
   *
   * - Filters out the product ID from the wishlist array
   */
  const removeFromWishlist = (productId) => {
    setWishlistItems((prev) => prev.filter((id) => id !== productId));
  };

  /**
   * Toggle a product's presence in the wishlist
   *
   * - Adds the product if it's not in the wishlist
   * - Removes the product if it is already in the wishlist
   */
  const toggleWishlist = (productId) => {
    setWishlistItems((prev) =>
      prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]
    );
  };

  // Provide wishlist data and functions to the rest of the app
  return (
    <WishlistContext.Provider
      value={{ wishlistItems, addToWishlist, removeFromWishlist, toggleWishlist }}
    >
      {children}
    </WishlistContext.Provider>
  );
};
