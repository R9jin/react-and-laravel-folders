import { createContext, useState, useEffect } from "react";
// Import fallback product data from a JSON file in case localStorage is empty or corrupted
import productsData from "../data/products.json";

// Create a context to share product data across components
export const ProductsContext = createContext();

/**
 * ProductsProvider Component
 *
 * Provides the product list and functions to update it for the entire app.
 * Features:
 * - Loads product data from localStorage if available
 * - Falls back to default products from products.json if localStorage is empty or corrupted
 * - Allows updating the product list and automatically saving it to localStorage
 */
export const ProductsProvider = ({ children }) => {
  // State to store the list of products
  const [products, setProducts] = useState([]);

  /**
   * Load products when the component mounts
   *
   * - Checks localStorage for saved products
   * - If valid products exist, loads them into state
   * - If no valid data or parsing fails, loads fallback products from JSON file
   * - Saves fallback products to localStorage to initialize persistent storage
   */
  useEffect(() => {
    const stored = localStorage.getItem("products");
    try {
      const parsed = stored ? JSON.parse(stored) : null;

      if (parsed && Array.isArray(parsed) && parsed.length > 0) {
        setProducts(parsed);
      } else {
        // Use fallback data if localStorage is empty or invalid
        setProducts(productsData);
        localStorage.setItem("products", JSON.stringify(productsData));
      }
    } catch {
      // Handle corrupted localStorage data by resetting to fallback
      setProducts(productsData);
      localStorage.setItem("products", JSON.stringify(productsData));
    }
  }, []);

  /**
   * Update the list of products
   *
   * - Replaces the current products state with newProducts
   * - Saves the updated list to localStorage for persistence
   */
  const updateProducts = (newProducts) => {
    setProducts(newProducts);
    localStorage.setItem("products", JSON.stringify(newProducts));
  };

  // Provide products and update function to the rest of the app
  return (
    <ProductsContext.Provider value={{ products, updateProducts }}>
      {children}
    </ProductsContext.Provider>
  );
};
