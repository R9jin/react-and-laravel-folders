# CCS112_Case-Study_E-Commerce_G10

# 🛒 Midterm Activity: React E-Commerce UI/UX Development

## 🎯 Objective
Develop the **UI/UX** of your e-commerce web application using **React.js**, following the sprint plan you created during the Prelim phase.

Each team member must actively contribute to the project using **Git** by creating **individual branches**, making **commits**, and submitting **pull requests** to demonstrate effective collaboration and version control.

---

## 🧩 Roles and Responsibilities

### 1. UI/UX Designer  
**Role:** taga-gawa ng Figma & document design rationale  
**Branch:** `ui-design`  
**Folder:** `/designs/` (include Figma links or screenshots of mockups)  
**Main Tasks:**
- Create wireframes/mockups for all pages  
- Decide on color scheme, typography, and layout  
- Prepare responsive layout guidelines  
- Document design rationale in a short markdown file  

---

### 2. Home and Navigation Developer — **Ticao**  
**Branch:** `home-navbar`  
**Components:** `Navbar.js`, `HomePage.js`  
**Main Tasks:**
- Implement Home page and Navigation Bar using React  
- Ensure navigation routes work (React Router)  
- Follow UI/UX design guidelines from the designer  

---

### 3. Integration Manager (GitHub Manager) — **Ticao**  
**Branch:** `integration-style`  
**Main Tasks:**
- Manage GitHub repository and branches  
- Handle pull requests and resolve merge conflicts  
- Review and integrate all components into `main` or `develop`  
- Ensure project runs successfully in Docker  

---

### 4. Product and Catalog Developer  
**Branch:** `product-pages`  
**Components:** `ProductList.js`, `ProductDetails.js`  
**Main Tasks:**
- Build Product Listing and Product Details pages  
- Create reusable components (e.g. `ProductCard`)  
- Integrate sample product data (`products.json`)  

---

### 5. Cart and Checkout Developer  
**Branch:** `cart-checkout`  
**Components:** `Cart.js`, `Checkout.js`  
**Main Tasks:**
- Develop Cart and Checkout UI  
- Handle basic state updates (item count, total price)  
- Use React hooks for interactivity  

---

### 6. Style Manager (taga-implement ng CSS) — **Vergara**  
**Branch:** `style-manager`  
**Files:** `App.js`, `index.css`, global style sheets  
**Main Tasks:**
- Unify CSS/styling using CSS Modules or Styled Components  
- Ensure consistent look and responsiveness  
- Work with Integration Manager to finalize the UI  

---

## 🪞 Reflection (for documentation)
Each member should answer briefly:
1. What part of the UI did you develop or design?  
2. What challenges did you encounter using Git for collaboration?  
3. How does your part contribute to the overall user experience?  
4. What improvements can be made to the interface or user flow?

---

## ⚙️ Git Workflow Summary
```bash
# 1. Clone the repository
git clone <repo-url>

# 2. Create and switch to your branch
git checkout -b <your-branch-name>

# 3. Add and commit changes
git add .
git commit -m "Added <feature>"

# 4. Push your branch to GitHub
git push origin <your-branch-name>

# 5. Create a Pull Request on GitHub for merging into 'develop'
